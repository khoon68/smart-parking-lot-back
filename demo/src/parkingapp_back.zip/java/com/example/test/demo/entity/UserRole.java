package com.example.test.demo.entity;

public enum UserRole {
    ADMIN,
    USER
}
