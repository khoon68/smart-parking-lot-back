package com.example.test.demo.repository;

public interface ParkingLotStats {
    Long getParkingLotId();
    String getParkingLotName();
    Long getTotalReservations();
    Integer getTotalRevenue();
}
