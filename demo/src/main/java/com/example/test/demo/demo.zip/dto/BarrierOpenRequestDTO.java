package com.example.test.demo.dto;

import lombok.Getter;

@Getter
public class BarrierOpenRequestDTO {
    private Long slotId;
}
