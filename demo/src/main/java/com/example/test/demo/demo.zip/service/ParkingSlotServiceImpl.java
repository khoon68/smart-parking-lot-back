package com.example.test.demo.service;

import com.example.test.demo.dto.ParkingSlotDTO;
import com.example.test.demo.entity.ParkingSlot;
import com.example.test.demo.repository.ParkingSlotRepository;
import com.example.test.demo.repository.ReservationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ParkingSlotServiceImpl implements ParkingSlotService{

    private final ParkingSlotRepository parkingSlotRepository;
    private final ReservationRepository reservationRepository;

    @Override
    public List<ParkingSlotDTO> findAvailableSlots(Long parkingLotId, LocalDate date, List<String> timeSlots) {

        List<ParkingSlot> allSlots = parkingSlotRepository.findByParkingLotId(parkingLotId);

        if (timeSlots.isEmpty()) return List.of();

        // 시간 문자열을 정렬하고 시작/끝 시간 계산
        List<String> sorted = timeSlots.stream().sorted().toList();
        String start = sorted.get(0);
        String end = sorted.get(sorted.size() - 1);

        LocalDateTime startTime = date.atTime(LocalTime.parse(start));
        LocalDateTime endTime = date.atTime(LocalTime.parse(end)).plusHours(1);

        // 해당 시간에 예약된 슬롯 ID 목록 조회
        Set<Long> reservedSlotIds = reservationRepository
                .findConflictsBySlot(parkingLotId, startTime, endTime)
                .stream()
                .map(r -> r.getParkingSlot().getId())
                .collect(Collectors.toSet());

        return allSlots.stream()
                .filter(slot -> !reservedSlotIds.contains(slot.getId()))
                .map(ParkingSlotDTO::from)
                .toList();
    }
}
